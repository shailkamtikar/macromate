---
name: MacroMate
colors:
  surface: '#fbf8fc'
  surface-dim: '#dcd9dd'
  surface-bright: '#fbf8fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f2f7'
  surface-container: '#f0edf1'
  surface-container-high: '#eae7eb'
  surface-container-highest: '#e4e1e6'
  on-surface: '#1b1b1e'
  on-surface-variant: '#3f493f'
  inverse-surface: '#303033'
  inverse-on-surface: '#f3f0f4'
  outline: '#6f7a6e'
  outline-variant: '#becabc'
  surface-tint: '#006d30'
  primary: '#00652c'
  on-primary: '#ffffff'
  primary-container: '#15803d'
  on-primary-container: '#d3ffd5'
  inverse-primary: '#79db8d'
  secondary: '#1f6c3a'
  on-secondary: '#ffffff'
  secondary-container: '#a4f1b2'
  on-secondary-container: '#24703e'
  tertiary: '#453bdc'
  on-tertiary: '#ffffff'
  tertiary-container: '#5f58f5'
  on-tertiary-container: '#f6f2ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#95f8a7'
  primary-fixed-dim: '#79db8d'
  on-primary-fixed: '#00210a'
  on-primary-fixed-variant: '#005323'
  secondary-fixed: '#a6f4b5'
  secondary-fixed-dim: '#8bd79b'
  on-secondary-fixed: '#00210b'
  on-secondary-fixed-variant: '#005226'
  tertiary-fixed: '#e2dfff'
  tertiary-fixed-dim: '#c3c0ff'
  on-tertiary-fixed: '#0f0069'
  on-tertiary-fixed-variant: '#3323cc'
  background: '#fbf8fc'
  on-background: '#1b1b1e'
  surface-variant: '#e4e1e6'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.5rem
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.625rem
    fontWeight: '700'
    lineHeight: 2.125rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-lg:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
  metric-numeral:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2rem
    letterSpacing: -0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  max-width-mobile: 28rem
  max-width-desktop: 72rem
---

## Brand & Style

The design system establishes an unhurried, reassuring, and functionally precise environment for everyday nutrition, macro management, and intelligent dietary coaching. Nutrition logging frequently triggers cognitive fatigue, anxiety, and visual overwhelm when handled through gamey neon progress dials or clinical hospital spreadsheets. This system takes the opposite route: warm editorial minimalism paired with high-legibility typographic hierarchy and crisp, tactile controls.

The target audience includes performance-focused athletes, everyday habit builders, and mindful eaters seeking frictionless one-thumb entries alongside intelligent analytical coaching. Visual priorities emphasize:
- **Calm, Organic Confidence:** Warm porcelain ground tones, muted olive and deep forest foliage greens, completely free of generic SaaS cyan/purple gradients and synthetic neon lighting.
- **Immediate Chromatic Parsing:** Strict semantic functional pigments dedicate dedicated hues to core metabolic metrics (Forest Green for Total Energy/Target, Indigo for Protein, Warm Amber for Carbohydrates, Rose for Dietary Fats, and Clean Sky Blue for Hydration).
- **Physical Weight & Restraint:** Utilitarian container structures with subtle warm borders, restrained rounded corners, and gentle surface stepping rather than loud drop-shadows or translucent frosted glass.

## Colors

The color palette is engineered for high data density, rapid optical scanning, and continuous all-day logging comfort across light and dark contexts.

### Theme Foundations
- **Light Mode Ground:** Warm porcelain canvas (`#FBFBFA`), elevated pure-white card containers (`#FFFFFF`), with architectural hairline borders (`#E6E5E2`).
- **Dark Mode Ground:** Deep charcoal slate-zinc base (`#0F1115`), middle elevation surfaces (`#181B20`), floating input/modal layers (`#21252C`), bounded by precise structural borders (`#2A2F3A`).
- **Primary Typography:** Deep charcoal (`#18181B`) in light mode; crisp illuminated zinc (`#F4F4F5`) in dark mode. Muted secondary labels utilize `#71717A` (light) and `#A1A1AA` (dark).

### Semantic & Macro Palette
- **Primary / Target Success:** Calm Forest Olive (`#15803D` light, `#22C55E` dark accent) for primary actions, logged statuses, and calorie targets.
- **Deep Botanical Anchor:** Deep Forest Green (`#166534`) for active toggle states and high-emphasis focal items.
- **Protein Metric:** Balanced Royal Indigo (`#4F46E5` light, `#818CF8` dark) conveying structure and muscular repair.
- **Carbohydrate Metric:** Warm Sun Amber (`#D97706` light, `#FBBF24` dark) reflecting sustained organic energy.
- **Fat Metric:** Natural Coral Rose (`#E11D48` light, `#FB7185` dark) denoting lipid reserves.
- **Hydration Metric:** Crisp Pure Sky (`#0284C7` light, `#38BDF8` dark) for liquid balance and water logging.

## Typography

Typography pairs the human, geometric warmth of **Plus Jakarta Sans** for headlines and high-impact nutrition totals with the functional, neutral clarity of **Inter** for descriptions, conversational AI coaching, table listings, and granular food specs.

Key formatting rules:
- **Numerical Data:** Calorie goals and macro gram quantities deploy `metric-numeral` set in Plus Jakarta Sans with tabular figures enabled (`font-variant-numeric: tabular-nums`) to prevent horizontal jitter during live calorie counter adjustments and real-time food entry updates.
- **Labels & Micro-Metrics:** All macro indicators (e.g., `CARBS 180g`, `PROTEIN 145g`) employ `label-md` or `label-sm` with subtle uppercase tracking to preserve instant legibility on compact mobile screens.
- **AI Coach Discourse:** AI response bubbles utilize `body-md` in Inter with a relaxed `1.6` line-height ratio, guaranteeing scannable, effortless reading of complex dietary advice without visual crowding.

## Layout & Spacing

Layout adheres to an 8pt base grid with a 4pt sub-grid reserved for tight data pairing, progress bars, and macro badges.

### Responsive Form Factors
- **Mobile Handheld (<640px):** Single-column layout constrained to safe-area bounds. Primary interactions, quick-log floating triggers, and barcode/search inputs reside within the bottom 45% thumb zone. Outer padding uses `gutter-mobile` (16px) with an 8px vertical gap between list rows to maintain clear tapping targets (minimum target height 48px).
- **Tablet / Split View (640px–1024px):** 6-column fluid grid. Today's calorie ring and macro summaries fix to the top half while historical meal cards and coach insights stack horizontally in 2-column segments.
- **Desktop Web (>1024px):** 12-column structured layout capped at a maximum width of 1152px (`max-width-desktop`). Left column hosts macro rings, daily deficit/surplus metrics, and hydration tracking; center column hosts chronologically segmented meal logs (Breakfast, Lunch, Dinner, Snacks); right column hosts conversational AI meal analysis and predictive coaching recommendations.

## Elevation & Depth

Visual hierarchy uses clean architectural layering, warm boundary definitions, and calibrated ambient lighting rather than heavy drop-shadows or translucent glassmorphism.

- **Level 0 (Base Canvas):** Background foundation (`#FBFBFA` light / `#0F1115` dark). Never cast shadows at this level.
- **Level 1 (Card & Section Containers):** Solid surfaces (`#FFFFFF` light / `#181B20` dark) paired with a 1px solid border (`#E6E5E2` light / `#2A2F3A` dark). A minimal diffuse ambient shadow is applied in light mode: `0 1px 3px 0 rgba(24, 24, 27, 0.04), 0 1px 2px -1px rgba(24, 24, 27, 0.03)`.
- **Level 2 (Interactive Elements & Dropdowns):** Meal breakdown sheets, select menus, and hovering food cards apply a soft lift: `0 4px 12px -2px rgba(24, 24, 27, 0.06), 0 2px 6px -2px rgba(24, 24, 27, 0.04)`.
- **Level 3 (Modals, Coach Drawer, Quick-Log Sheet):** High-level overlay surfaces (`#FFFFFF` light / `#21252C` dark) bounded by crisp borders and deep ambient depth: `0 20px 25px -5px rgba(24, 24, 27, 0.08), 0 8px 10px -6px rgba(24, 24, 27, 0.04)`. Dark mode completely omits black shadow washes and relies entirely on elevated surface tones and 1px border contrast.

## Shapes

The geometric framework is calibrated to `roundedness: 2`, delivering a balanced, tailored feel that avoids both harsh sharp corners and juvenile hyper-rounded bubbles.

- **Standard Containers & Cards:** `0.5rem` (8px) base radius, stepping up to `1rem` (16px) for major dashboard cards and log containers.
- **Interactive Buttons & Form Fields:** `0.5rem` (8px) across text inputs, quantity pickers, and primary call-to-actions.
- **Macro Badges & Progress Bars:** Progress rail tracks feature an exact `0.5rem` (8px) radius with matching inner fills to ensure smooth visual tracking.
- **Exceptions:** Compact status pills and hydration tap units utilize full circular ends (`rounded-full`) exclusively when representing discrete binary states or round incremental buttons (+250ml water buttons).

## Components

### Buttons
- **Primary (Action):** Background `#15803D`, text `#FFFFFF`, border none, 8px radius, height 44px (mobile 48px). Hover state shifts to `#166534`. Active press shifts visually via subtle scale reduction (`0.985`).
- **Secondary (Neutral Outline):** Background `#FFFFFF` (light) / `#181B20` (dark), border 1px solid `#E6E5E2` (light) / `#2A2F3A` (dark), text `#18181B` (light) / `#F4F4F5` (dark).
- **Destructive:** Rose border and text (`#E11D48`), background `#FFF1F2` (light) or `#2A1218` (dark).

### Macro Progress Indicators
- Linear and circular indicators feature a muted trough track (`#F4F4F5` light / `#21252C` dark).
- Progress fills apply pure, solid macro assignments without multi-color gradients:
  - Calories: `#15803D`
  - Protein: `#4F46E5`
  - Carbs: `#D97706`
  - Fats: `#E11D48`
  - Water: `#0284C7`
- Smooth transition animations (300ms cubic-bezier(0.16, 1, 0.3, 1)) on log completion.

### Meal & Food Item Cards
- Surface: `#FFFFFF` (light) / `#181B20` (dark) with 1px border.
- Layout: Left side displays food name (`body-md`, semibold) with brand/measurement details (`body-sm`, muted zinc). Right side presents energy quantity (`Plus Jakarta Sans`, 700) aligned with an inline horizontal dot badge showing macro proportions (P/C/F).
- Swipe Action (Mobile): Smooth left-drag reveals quick-delete (Rose) and quick-repeat (Forest Green).

### Input Fields & Search Bars
- Standard input height 44px, 8px corner radius.
- Inactive state: 1px border `#E6E5E2` (light) / `#2A2F3A` (dark), background `#FAFAFA` (light) / `#13161A` (dark).
- Focused state: Background `#FFFFFF` (light) / `#181B20` (dark), 1px border `#15803D`, with an optical focus ring: `0 0 0 3px rgba(21, 128, 61, 0.15)`.

### AI Coach Intelligence Cards
- Border treatment: Subtle olive-tinted stroke (`rgba(21, 128, 61, 0.25)`).
- Header: Subtle icon tag in `#15803D` labeled "DAILY COACH INSIGHT" using `label-sm`.
- Content: Direct, conversational tone in `body-md` providing macro optimization suggestions (e.g., "Protein is 24g under target before dinner. A 200g Greek yogurt portion closes this gap."). Includes 1-tap contextual action buttons: "+ Quick Add Suggestion".

### Hydration Tracker Unit
- Card container displaying daily total in large `display-lg-mobile` numerals accompanied by sky blue accent (`#0284C7`).
- Quick-log pill row featuring presets: `+250ml`, `+500ml`, `+750ml` with sky blue low-contrast outlines that fill momentarily with liquid blue feedback upon touch.